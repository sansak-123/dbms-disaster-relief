const mongoose = require("mongoose");

const resourceSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    quantity: { type: Number, required: true },
    unit: { type: String, required: true },
    zone_id: { type: mongoose.Schema.Types.ObjectId, ref: "Zone" }, // Optional reference
  },
  { timestamps: true }
);

module.exports = mongoose.model("Resource", resourceSchema);
