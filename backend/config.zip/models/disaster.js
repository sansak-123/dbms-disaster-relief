const mongoose = require("mongoose");

const disasterSchema = new mongoose.Schema({
  type: { type: String, required: true },
  location: String,
  severity: String,
  date: Date,
});

module.exports = mongoose.model("Disaster", disasterSchema);
