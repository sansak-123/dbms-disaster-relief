const express = require("express");
const router = express.Router();
const Volunteer = require("../models/Volunteer");
const AuditLog = require("../models/AuditLog");

// GET all volunteers with zone info
router.get("/", async (req, res) => {
  const volunteers = await Volunteer.find().populate(
    "zone_id",
    "name description"
  );
  res.json(volunteers);
});

// POST new volunteer
router.post("/", async (req, res) => {
  const volunteer = new Volunteer(req.body);
  const saved = await volunteer.save();

  await AuditLog.create({
    action: "ADD_VOLUNTEER",
    collectionName: "Volunteers",
    recordId: saved._id,
    newData: saved,
  });

  res.json(saved);
});

// PUT update volunteer
router.put("/:id", async (req, res) => {
  const oldData = await Volunteer.findById(req.params.id);
  const updated = await Volunteer.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
  });

  await AuditLog.create({
    action: "UPDATE_VOLUNTEER",
    collectionName: "Volunteers",
    recordId: updated._id,
    oldData,
    newData: updated,
  });

  res.json(updated);
});

// DELETE volunteer
router.delete("/:id", async (req, res) => {
  const deleted = await Volunteer.findByIdAndDelete(req.params.id);

  await AuditLog.create({
    action: "DELETE_VOLUNTEER",
    collectionName: "Volunteers",
    recordId: deleted._id,
    oldData: deleted,
  });

  res.json({ message: "Volunteer deleted" });
});

module.exports = router;
