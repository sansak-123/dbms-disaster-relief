const express = require("express");
const router = express.Router();
const Resource = require("../models/Resource");
const AuditLog = require("../models/AuditLog");

// GET all resources with zone info
router.get("/", async (req, res) => {
  const resources = await Resource.find().populate(
    "zone_id",
    "name description"
  );
  res.json(resources);
});

// POST new resource
router.post("/", async (req, res) => {
  const resource = new Resource(req.body);
  const saved = await resource.save();

  await AuditLog.create({
    action: "ADD_RESOURCE",
    collectionName: "Resources",
    recordId: saved._id,
    newData: saved,
  });

  res.json(saved);
});

// PUT update resource
router.put("/:id", async (req, res) => {
  const oldData = await Resource.findById(req.params.id);
  const updated = await Resource.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
  });

  await AuditLog.create({
    action: "UPDATE_RESOURCE",
    collectionName: "Resources",
    recordId: updated._id,
    oldData,
    newData: updated,
  });

  res.json(updated);
});

// DELETE resource
router.delete("/:id", async (req, res) => {
  const deleted = await Resource.findByIdAndDelete(req.params.id);

  await AuditLog.create({
    action: "DELETE_RESOURCE",
    collectionName: "Resources",
    recordId: deleted._id,
    oldData: deleted,
  });

  res.json({ message: "Resource deleted" });
});

module.exports = router;
