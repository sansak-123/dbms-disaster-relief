const express = require("express");
const router = express.Router();
const Zone = require("../models/Zone");
const AuditLog = require("../models/AuditLog");

// GET all zones
router.get("/", async (req, res) => {
  const zones = await Zone.find();
  res.json(zones);
});

// POST new zone
router.post("/", async (req, res) => {
  const zone = new Zone(req.body);
  const saved = await zone.save();

  await AuditLog.create({
    action: "ADD_ZONE",
    collectionName: "Zones",
    recordId: saved._id,
    newData: saved,
  });

  res.json(saved);
});

// PUT update zone
router.put("/:id", async (req, res) => {
  const oldData = await Zone.findById(req.params.id);
  const updated = await Zone.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
  });

  await AuditLog.create({
    action: "UPDATE_ZONE",
    collectionName: "Zones",
    recordId: updated._id,
    oldData,
    newData: updated,
  });

  res.json(updated);
});

// DELETE zone
router.delete("/:id", async (req, res) => {
  const deleted = await Zone.findByIdAndDelete(req.params.id);

  await AuditLog.create({
    action: "DELETE_ZONE",
    collectionName: "Zones",
    recordId: deleted._id,
    oldData: deleted,
  });

  res.json({ message: "Zone deleted" });
});

module.exports = router;
