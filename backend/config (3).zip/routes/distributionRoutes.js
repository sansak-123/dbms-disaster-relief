const express = require("express");
const router = express.Router();
const DistributionRecord = require("../models/DistributionRecord");
const AuditLog = require("../models/AuditLog");

// GET all distribution records with populated references
router.get("/", async (req, res) => {
  const records = await DistributionRecord.find()
    .populate("request_id", "disaster_id resource_id quantity status location")
    .populate("volunteer_id", "name skills availability")
    .populate("resource_id", "name quantity unit");
  res.json(records);
});

// POST new distribution record
router.post("/", async (req, res) => {
  const record = new DistributionRecord(req.body);
  const saved = await record.save();

  await AuditLog.create({
    action: "ADD_DISTRIBUTION",
    collectionName: "DistributionRecords",
    recordId: saved._id,
    newData: saved,
  });

  res.json(saved);
});

// PUT update record
router.put("/:id", async (req, res) => {
  const oldData = await DistributionRecord.findById(req.params.id);
  const updated = await DistributionRecord.findByIdAndUpdate(
    req.params.id,
    req.body,
    { new: true }
  );

  await AuditLog.create({
    action: "UPDATE_DISTRIBUTION",
    collectionName: "DistributionRecords",
    recordId: updated._id,
    oldData,
    newData: updated,
  });

  res.json(updated);
});

// DELETE record
router.delete("/:id", async (req, res) => {
  const deleted = await DistributionRecord.findByIdAndDelete(req.params.id);

  await AuditLog.create({
    action: "DELETE_DISTRIBUTION",
    collectionName: "DistributionRecords",
    recordId: deleted._id,
    oldData: deleted,
  });

  res.json({ message: "Distribution record deleted" });
});

module.exports = router;
