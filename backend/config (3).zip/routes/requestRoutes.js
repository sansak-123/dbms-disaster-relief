const express = require("express");
const router = express.Router();
const Request = require("../models/Request");
const AuditLog = require("../models/AuditLog");

// GET all requests with disaster and resource info
router.get("/", async (req, res) => {
  const requests = await Request.find()
    .populate("disaster_id", "type location date")
    .populate("resource_id", "name quantity unit");
  res.json(requests);
});

// POST new request
router.post("/", async (req, res) => {
  const request = new Request(req.body);
  const saved = await request.save();

  await AuditLog.create({
    action: "ADD_REQUEST",
    collectionName: "Requests",
    recordId: saved._id,
    newData: saved,
  });

  res.json(saved);
});

// PUT update request
router.put("/:id", async (req, res) => {
  const oldData = await Request.findById(req.params.id);
  const updated = await Request.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
  });

  await AuditLog.create({
    action: "UPDATE_REQUEST",
    collectionName: "Requests",
    recordId: updated._id,
    oldData,
    newData: updated,
  });

  res.json(updated);
});

// DELETE request
router.delete("/:id", async (req, res) => {
  const deleted = await Request.findByIdAndDelete(req.params.id);

  await AuditLog.create({
    action: "DELETE_REQUEST",
    collectionName: "Requests",
    recordId: deleted._id,
    oldData: deleted,
  });

  res.json({ message: "Request deleted" });
});

module.exports = router;
