const mongoose = require("mongoose");

const volunteerSchema = new mongoose.Schema({
  name: String,
  skills: [String],
  availability: { type: Boolean, default: true },
  zone_id: { type: mongoose.Schema.Types.ObjectId, ref: "Zone" }, // Reference
});

module.exports = mongoose.model("Volunteer", volunteerSchema);
